import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty) {
    await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  }
  runApp(const AamirApp());
}

class AamirApp extends StatelessWidget {
  const AamirApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AAMIR MULTIMEDIA',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF075B55),
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF102A2A),
        useMaterial3: true,
      ),
      home: const WelcomePage(),
    );
  }
}

class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Image.asset('assets/aamir_logo.jpg', height: 210),
                ),
                const SizedBox(height: 20),
                const Text(
                  'AAMIR MULTIMEDIA',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 27,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 8),
                const Text('Nasheed • Listen • Download'),
                const SizedBox(height: 28),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const AuthPage()),
                    ),
                    child: const Text('Login / Sign Up'),
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  'Dhaggeeffadhu • Buufadhu • Walitti makami',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white70),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});

  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final emailController = TextEditingController();
  final phoneController = TextEditingController();
  final passwordController = TextEditingController();
  final otpController = TextEditingController();
  bool isLogin = false;
  bool usePhone = false;
  bool busy = false;
  String message = '';

  bool get configured => supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty;

  Future<void> emailAction() async {
    if (!configured) {
      setState(() => message =
          'Backend hin qindaa’inne. README.md keessatti qajeelfama ilaali.');
      return;
    }
    setState(() { busy = true; message = ''; });
    try {
      final auth = Supabase.instance.client.auth;
      if (isLogin) {
        await auth.signInWithPassword(
          email: emailController.text.trim(),
          password: passwordController.text,
        );
        setState(() => message = 'Seenteetta. Fuulli nashiidaa itti aanu qindaa’uu qaba.');
      } else {
        await auth.signUp(
          email: emailController.text.trim(),
          password: passwordController.text,
        );
        setState(() => message =
            'Account uumame. Email kee mirkaneessi yoo mirkaneessuun hojii irra jiraate.');
      }
    } on AuthException catch (e) {
      setState(() => message = e.message);
    } catch (e) {
      setState(() => message = 'Dogoggorri uumame. Yaali irra deebi’i.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> sendPhoneCode() async {
    if (!configured) {
      setState(() => message =
          'Backend hin qindaa’inne. README.md keessatti qajeelfama ilaali.');
      return;
    }
    setState(() { busy = true; message = ''; });
    try {
      await Supabase.instance.client.auth.signInWithOtp(
        phone: phoneController.text.trim(),
      );
      setState(() => message = 'Koodiin mirkaneessaa ergame. Amma koodii galchi.');
    } on AuthException catch (e) {
      setState(() => message = e.message);
    } catch (e) {
      setState(() => message = 'Koodii erguun hin milkoofne.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> verifyPhoneCode() async {
    if (!configured) return;
    setState(() { busy = true; message = ''; });
    try {
      await Supabase.instance.client.auth.verifyOTP(
        phone: phoneController.text.trim(),
        token: otpController.text.trim(),
        type: OtpType.sms,
      );
      setState(() => message = 'Lakkoofsi bilbilaa mirkanaa’e.');
    } on AuthException catch (e) {
      setState(() => message = e.message);
    } catch (e) {
      setState(() => message = 'Mirkaneessuun hin milkoofne.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    emailController.dispose();
    phoneController.dispose();
    passwordController.dispose();
    otpController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Account AAMIR MULTIMEDIA')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          SegmentedButton<bool>(
            segments: const [
              ButtonSegment(value: false, label: Text('Account Uumi')),
              ButtonSegment(value: true, label: Text('Login')),
            ],
            selected: {isLogin},
            onSelectionChanged: (v) => setState(() => isLogin = v.first),
          ),
          const SizedBox(height: 18),
          SegmentedButton<bool>(
            segments: const [
              ButtonSegment(value: false, label: Text('Email')),
              ButtonSegment(value: true, label: Text('Bilbila')),
            ],
            selected: {usePhone},
            onSelectionChanged: (v) => setState(() => usePhone = v.first),
          ),
          const SizedBox(height: 18),
          if (!usePhone) ...[
            TextField(
              controller: emailController,
              keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(
                labelText: 'Email',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: passwordController,
              obscureText: true,
              decoration: const InputDecoration(
                labelText: 'Password',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: busy ? null : emailAction,
              child: Text(busy ? 'Eegaa...' : (isLogin ? 'Login' : 'Sign Up')),
            ),
          ] else ...[
            TextField(
              controller: phoneController,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                labelText: 'Lakkoofsa bilbilaa (fakkeenya +251...)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: busy ? null : sendPhoneCode,
              child: const Text('Koodii SMS ergi'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: otpController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Koodii SMS',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton.tonal(
              onPressed: busy ? null : verifyPhoneCode,
              child: const Text('Koodii mirkaneessi'),
            ),
          ],
          if (message.isNotEmpty) ...[
            const SizedBox(height: 18),
            Text(message, style: const TextStyle(color: Colors.amberAccent)),
          ],
        ],
      ),
    );
  }
}
