# AAMIR MULTIMEDIA — Flutter starter

This is a starter Android app project using the logo supplied in the chat.
It includes a welcome screen and starter authentication flows for:
- Email + password
- Phone number + SMS one-time code

## Important
This is source code, not a finished installable APK. The backend must be configured,
then the app must be built and tested with Flutter/Android tooling.

## 1. Create a Supabase project
1. Create a project at https://supabase.com/
2. In Authentication settings, enable Email.
3. For phone sign-in, enable Phone and configure an SMS provider supported by Supabase.
   SMS delivery may have a cost; a fully free SMS service is not guaranteed.
4. Copy the Project URL and anon/public key from Project Settings > API.

## 2. Run the app
Install Flutter and Android Studio, then run:

```bash
flutter pub get
flutter run --dart-define=SUPABASE_URL=YOUR_PROJECT_URL --dart-define=SUPABASE_ANON_KEY=YOUR_ANON_KEY
```

Do not put a Supabase service-role secret in the mobile app. Only use the anon/public key.

## 3. Build an APK
After backend configuration and testing:

```bash
flutter build apk --release --dart-define=SUPABASE_URL=YOUR_PROJECT_URL --dart-define=SUPABASE_ANON_KEY=YOUR_ANON_KEY
```

The APK will be created at:
`build/app/outputs/flutter-apk/app-release.apk`

## 4. Next development steps
- Add a secure admin role (never rely on a hidden button alone).
- Add a database table for nasheeds and metadata.
- Add private/admin-only upload permissions and public listening/download rules.
- Add audio playback, cover art, search, favourites and download management.
- Test account creation, login, SMS delivery, audio playback and downloads.

The app is not ready for public release until these steps and security rules are completed.
